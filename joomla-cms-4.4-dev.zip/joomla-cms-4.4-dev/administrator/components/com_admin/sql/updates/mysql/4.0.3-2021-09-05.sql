UPDATE `#__workflow_transitions` SET `title` = 'PUBLISH' WHERE `title`= 'Publish';
UPDATE `#__workflow_transitions` SET `title` = 'UNPUBLISH' WHERE `title`= 'Unpublish';
UPDATE `#__workflow_transitions` SET `title` = 'TRASH' WHERE `title`= 'Trash';
UPDATE `#__workflow_transitions` SET `title` = 'ARCHIVE' WHERE `title`= 'Archive';
UPDATE `#__workflow_transitions` SET `title` = 'FEATURE' WHERE `title`= 'Feature';
UPDATE `#__workflow_transitions` SET `title` = 'UNFEATURE' WHERE `title`= 'Unfeature';
UPDATE `#__workflow_transitions` SET `title` = 'PUBLISH_AND_FEATURE' WHERE `title`= 'Publish & Feature';
