DELETE FROM "#__postinstall_messages" WHERE "title_key" = 'COM_ADMIN_POSTINSTALL_MSG_FLOC_BLOCKER_TITLE';
