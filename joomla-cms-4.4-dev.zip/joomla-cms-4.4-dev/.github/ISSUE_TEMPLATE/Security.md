---
name: Security
about: Report a security issue

---

Security issues should **NOT** be reported on this repository.

If you believe you have found a security issue, please contact the Joomla Security Strike Team via email at security@joomla.org or through the contact form at https://developer.joomla.org/security/contact-the-team.html.

Please see https://developer.joomla.org/security.html for more information on how the Joomla project responds to security issues.
